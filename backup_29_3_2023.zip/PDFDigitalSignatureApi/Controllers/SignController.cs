﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.security;
using System.Net;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.WebUtilities;
using System.IO;
using System.Diagnostics;

namespace PDFDigitalSignatureApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SignController : ControllerBase
    {

        [HttpPost]
        public IActionResult Post([FromForm] Sign data)
        {
            try
            {
                string path = Directory.GetCurrentDirectory();
                //string path = Path.Combine("https://digitalsignpdf.azurewebsites.net/", "wwwroot/Files"); 

                //create folder if not exist
                //if (!Directory.Exists(path))
                //    Directory.CreateDirectory(path);

                //get file extension
                //FileInfo fileInfo = new FileInfo(data.PdfFile.FileName);
                //string fileName = Path.GetFileNameWithoutExtension(data.PdfFile.FileName) + DateTime.Now.Ticks + fileInfo.Extension;
                //string PdfToSign = Path.Combine(path, fileName);

                //using (var stream = new FileStream(PdfToSign, FileMode.Create))
                //{
                //    data.PdfFile.CopyTo(stream);
                //}

                FileInfo fileInfo1 = new FileInfo(data.PfxFile.FileName);
                string fileName1 = Path.GetFileNameWithoutExtension(data.PfxFile.FileName) + DateTime.Now.Ticks + fileInfo1.Extension;
                string SignPfx = Path.Combine(path, fileName1);

                using (var stream1 = new FileStream(SignPfx, FileMode.Create))
                {
                    data.PfxFile.CopyTo(stream1);
                }

                string newPdfFilePath1 = Path.Combine(path, "new" + DateTime.Now.Ticks + ".pdf");
                FileStream fileStream1 = new FileStream(SignPfx, FileMode.Open);

                signPdfFile(data.PdfFile, newPdfFilePath1, fileStream1, data.Password, data.reason, data.location, data);

                byte[] fileBytes = System.IO.File.ReadAllBytes(newPdfFilePath1);
                var dataStream = new MemoryStream(fileBytes);
                // return fileBytes;

                //HttpRequestMessage request = new HttpRequestMessage();
                //HttpResponseMessage httpResponseMessage = request.CreateResponse(HttpStatusCode.OK);
                //httpResponseMessage.Content = new StreamContent(dataStream);
                //httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                //httpResponseMessage.Content.Headers.ContentDisposition.FileName = "sad.pdf";
                //httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");

                //return httpResponseMessage;

                HttpContext.Response.ContentType = "application/pdf";
                FileContentResult result = new FileContentResult(System.IO.File.ReadAllBytes(newPdfFilePath1), "application/pdf")
                {
                    FileDownloadName = "SignedFile" + DateTime.Now + ".pdf"
                };

                return result;


            }
            catch (Exception ex)
            {
                var st = new StackTrace(ex, true);
                var frame = st.GetFrame(0);
                var line = frame.GetFileLineNumber();
                return StatusCode(500, "Internal server errors:" + ex.ToString() + " sdsd " + Directory.GetCurrentDirectory());
            }
        }


        public static void signPdfFile(IFormFile pdffile, string destinationPath, Stream privateKeyStream, string keyPassword, string reason, string location, Sign data)
        {
            Org.BouncyCastle.Pkcs.Pkcs12Store pk12 = new Org.BouncyCastle.Pkcs.Pkcs12Store(privateKeyStream, keyPassword.ToCharArray());
            privateKeyStream.Dispose();

            //then Iterate throught certificate entries to find the private key entry
            string alias = null;
            foreach (string tAlias in pk12.Aliases)
            {
                if (pk12.IsKeyEntry(tAlias))
                {
                    alias = tAlias;
                    break;
                }
            }
            var pk = pk12.GetKey(alias).Key;

            //var streampfx = pfxFile.OpenReadStream();
            //byte[] bytes = new byte[pfxFile.Length];
            //streampfx.Read(bytes, 0, (int)pfxFile.Length);

            //X509Certificate2 cert1 = new X509Certificate2(bytes, keyPassword, X509KeyStorageFlags.Exportable);
            //RSA legacyProv = (RSA)cert1.PrivateKey;
            //RSACryptoServiceProvider provider = new RSACryptoServiceProvider();
            //provider.ImportParameters(legacyProv.ExportParameters(true));
            //var psdk = Org.BouncyCastle.Security.DotNetUtilities.GetRsaKeyPair(provider).Private;

            // reader and stamper
            var streampdf = pdffile.OpenReadStream();
            

            PdfReader reader = new PdfReader(streampdf);
            using (FileStream fout = new FileStream(destinationPath, FileMode.Create, FileAccess.ReadWrite))
            {
                PdfStamper stamper = PdfStamper.CreateSignature(reader, fout, '\0');
                // appearance
                PdfSignatureAppearance appearance = stamper.SignatureAppearance;
                //appearance.Image = new iTextSharp.text.pdf.PdfImage();
                appearance.Reason = reason;
                appearance.Location = location;
                appearance.SetVisibleSignature(new iTextSharp.text.Rectangle(data.PageX, data.PageY, data.Height, data.Width), reader.NumberOfPages, "signature");
                // digital signature
                IExternalSignature es = new PrivateKeySignature(pk, DigestAlgorithms.SHA256);
                MakeSignature.SignDetached(appearance, es, new Org.BouncyCastle.X509.X509Certificate[] { pk12.GetCertificate(alias).Certificate }, null, null, null, 0, CryptoStandard.CMS);
                stamper.Close();
            }

        }
    }
}
